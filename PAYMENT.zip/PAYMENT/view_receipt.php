<?php
// Retrieve the filename from the URL parameter
session_start();
$user=$_SESSION['user']??"";
$id=$_GET['id'];
$time=$_GET['time'];
$date=$_GET['date'];
$connect=mysqli_connect("localhost","root","","project");

$sql="SELECT * FROM `order` WHERE username='$user'and date='$date' and  time='$time' " ;
$result=mysqli_query($connect,$sql);

$filename = $_GET['filename'] ?? '';
if(mysqli_num_rows($result)> 0){
    while($row=mysqli_fetch_array($result)){
        echo "<img src='" . $row["image"] . "' alt='Custom Image' height=150px width=200px><br><br>";
        echo "<label>product: " . $row["product"] . "</label><br>";
        echo "<label>product discription: " . $row["discription"] . "</label><br>";
        if ($row['category'] == 't shirt' || $row['category'] == 'hoodies') {
            
            echo "<label>size: " . $row["size"] . "</label><br>";
        }
        echo "<label>quantity: " . $row["quantity"] . "</label><br>";
        echo "<label>price: ₹" . $row["price"] . "</label><br>";
        echo "<label>Username: " . $row["username"] . "</label><br>";
        echo "<label>delivery_adderess: " . $row["user_address"] . "</label><br>";
        echo "<label>seller name: " . $row["sellername"] . "</label><br>";
    }
}
else{
    echo"hii";
}
if ($filename) {
    // Read the content of the receipt file
    $receipt_content = file_get_contents($filename);

    // Display only the download link on the page
    echo "Download Receipt: <a href='$filename' download>Download Receipt</a>";
} else {
    // Handle the case where the filename is not provided
    echo "Invalid request.";
}
?>
