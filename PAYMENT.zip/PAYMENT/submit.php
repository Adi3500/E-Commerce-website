<?php
session_start();
$username = $_SESSION['user'];

$connect = mysqli_connect("localhost", "root", "", "project");
$id = $_GET['id'] ?? "";
$size = $_GET['size'] ?? "";
$quantity = intval($_GET['quantity'] ?? "");
$sql = "SELECT * FROM product WHERE id = '$id'";
$result = mysqli_query($connect, $sql);
$row = mysqli_fetch_array($result);
$pname = $row['product'];
$pprice = $row['price'];
$dis=$row['discription'];
$category=$row['category'];
$seller=$row['seller_name'];
$del_charge = 50;
$tot_price = ($pprice * $quantity) + $del_charge;
$image = $row['image'];
$q="SELECT * FROM `seller` WHERE sellername='$seller'";
$r = mysqli_query($connect, $q);
$ro = mysqli_fetch_array($r);
$seller_contact= $ro[5];
$qe="SELECT * FROM `registration` WHERE username='$username'";
$re = mysqli_query($connect, $qe);
$ra = mysqli_fetch_array($re);
$user_contact= $ra["mobile"];
$user_address= $ra["address"];
$user_email= $ra["email"];
$date= date("Y-m-d");
$time= date("h:i:s");
$sqll="INSERT INTO `order`(`product_id`, `sellername`, `username`, `product`, `discription`, `category`, `price`, `image`, `size`, `quantity`, `user_contact`, `user_address`, `seller_contact`,`date`,`time`) VALUES ('$id','$seller','$username','$pname','$dis','$category','$pprice','$image','$size','$quantity','$user_contact','$user_address','$seller_contact','$date','$time')";
$results=mysqli_query($connect,$sqll);
// Include the Stripe PHP library
require("./config.php");

// Disable SSL certificate verification for Stripe
\Stripe\Stripe::setVerifySslCerts(false);

// Get the Stripe token from the submitted form
$token = $_POST['stripeToken'];

try {
    // Create a charge using Stripe API
    $data = \Stripe\Charge::create([
        'amount' => $tot_price * 100, // Stripe requires the amount in cents
        'currency' => 'inr',
        'description' => 'Shopflix - ' . $pname,
        'source' => $token,
        // You can include other parameters as needed...
    ]);

    // Generate receipt content
    $receipt_content = "Receipt for Order\n";
    $receipt_content .= "Product: $pname\n";
    $receipt_content .= "Price: ₹$pprice\n";
    $receipt_content .= "Delivery Charge: ₹$del_charge\n";
    $receipt_content .= "Total Price: ₹$tot_price\n";

    // Save the receipt to a file
    $receipt_filename = "receipt_" . time() . ".txt";
    file_put_contents($receipt_filename, $receipt_content);

    // Redirect to the receipt display page with the filename as a parameter
    header("Location: view_receipt.php?filename=$receipt_filename&id=$id&date=$date&time=$time&user=$username");
    exit();
} catch (\Stripe\Exception\InvalidRequestException $e) {
    // Handle Stripe API exceptions
    echo 'Error: ' . $e->getMessage();
} catch (Exception $e) {
    // Handle other exceptions
    echo 'Error: ' . $e->getMessage();
}
?>
